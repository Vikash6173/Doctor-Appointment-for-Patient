// User Authentication
const users = JSON.parse(localStorage.getItem('users')) || [];
let currentUser = JSON.parse(sessionStorage.getItem('currentUser')) || null;

// DOM Elements
const loginOverlay = document.getElementById('loginOverlay');
const mainContent = document.getElementById('mainContent');
const loginForm = document.getElementById('loginForm');
const registerForm = document.getElementById('registerForm');
const showRegister = document.getElementById('showRegister');
const showLogin = document.getElementById('showLogin');
const logoutBtn = document.getElementById('logoutBtn');
const userGreeting = document.getElementById('userGreeting');
const bookTab = document.getElementById('bookTab');
const historyTab = document.getElementById('historyTab');
const bookingSection = document.getElementById('bookingSection');
const historySection = document.getElementById('historySection');
const appointmentsList = document.getElementById('appointmentsList');

// Initialize
if (currentUser) {
  loginOverlay.style.display = 'none';
  mainContent.classList.remove('hidden');
  updateUserGreeting();
  loadAppointments();
} else {
  loginOverlay.style.display = 'flex';
  mainContent.classList.add('hidden');
}

// Event Listeners
showRegister.addEventListener('click', (e) => {
  e.preventDefault();
  loginForm.classList.add('hidden');
  registerForm.classList.remove('hidden');
});

showLogin.addEventListener('click', (e) => {
  e.preventDefault();
  registerForm.classList.add('hidden');
  loginForm.classList.remove('hidden');
});

loginForm.addEventListener('submit', (e) => {
  e.preventDefault();
  const email = document.getElementById('loginEmail').value;
  const password = document.getElementById('loginPassword').value;
  
  const user = users.find(u => u.email === email && u.password === password);
  if (user) {
    currentUser = user;
    sessionStorage.setItem('currentUser', JSON.stringify(currentUser));
    loginOverlay.style.display = 'none';
    mainContent.classList.remove('hidden');
    updateUserGreeting();
    loadAppointments();
  } else {
    alert('Invalid email or password');
  }
});

registerForm.addEventListener('submit', (e) => {
  e.preventDefault();
  const name = document.getElementById('regName').value;
  const email = document.getElementById('regEmail').value;
  const phone = document.getElementById('regPhone').value;
  const password = document.getElementById('regPassword').value;
  
  if (users.some(u => u.email === email)) {
    alert('Email already registered');
    return;
  }
  
  const newUser = {
    id: Date.now().toString(),
    name,
    email,
    phone,
    password,
    appointments: []
  };
  
  users.push(newUser);
  localStorage.setItem('users', JSON.stringify(users));
  
  currentUser = newUser;
  sessionStorage.setItem('currentUser', JSON.stringify(currentUser));
  
  registerForm.classList.add('hidden');
  loginForm.classList.remove('hidden');
  registerForm.reset();
  
  loginOverlay.style.display = 'none';
  mainContent.classList.remove('hidden');
  updateUserGreeting();
});

logoutBtn.addEventListener('click', () => {
  sessionStorage.removeItem('currentUser');
  currentUser = null;
  loginOverlay.style.display = 'flex';
  mainContent.classList.add('hidden');
});

bookTab.addEventListener('click', () => {
  bookTab.classList.add('active');
  historyTab.classList.remove('active');
  bookingSection.classList.remove('hidden');
  historySection.classList.add('hidden');
});

historyTab.addEventListener('click', () => {
  historyTab.classList.add('active');
  bookTab.classList.remove('active');
  historySection.classList.remove('hidden');
  bookingSection.classList.add('hidden');
  loadAppointments();
});

// Helper Functions
function updateUserGreeting() {
  if (currentUser) {
    userGreeting.textContent = `Hello, ${currentUser.name.split(' ')[0]}`;
  }
}

function loadAppointments() {
  if (!currentUser) return;
  
  appointmentsList.innerHTML = '';
  
  if (currentUser.appointments.length === 0) {
    appointmentsList.innerHTML = '<p>No appointments booked yet.</p>';
    return;
  }
  
  currentUser.appointments.forEach(appointment => {
    const card = document.createElement('div');
    card.className = 'appointment-card';
    card.innerHTML = `
      <h3><i class="fas fa-calendar-check"></i> ${appointment.date}</h3>
      <p><i class="fas fa-clock"></i> ${appointment.time}</p>
      <p><i class="fas fa-user-md"></i> ${appointment.doctor}</p>
      <p><i class="fas fa-clinic-medical"></i> ${appointment.department}</p>
    `;
    appointmentsList.appendChild(card);
  });
}

// Existing Appointment Booking Code (modified to save to user)
const doctorList = {
  Cardiology: ["Dr. Mehra", "Dr. Patel"],
  Dermatology: ["Dr. Sharma", "Dr. Nisha"],
  Pediatrics: ["Dr. Roy", "Dr. Krishna"],
  General: ["Dr. Thomas", "Dr. Ayesha"]
};

const department = document.getElementById("department");
const doctor = document.getElementById("doctor");

department.addEventListener("change", () => {
  const selected = department.value;
  doctor.innerHTML = '<option value="">-- Select Doctor --</option>';
  if (doctorList[selected]) {
    doctorList[selected].forEach(doc => {
      const opt = document.createElement("option");
      opt.value = doc;
      opt.text = doc;
      doctor.appendChild(opt);
    });
  }
});

// Calendar
const calendar = document.getElementById("calendar");
const hiddenDate = document.getElementById("date");
const days = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];

function generateCalendar() {
  const today = new Date();
  const year = today.getFullYear();
  const month = today.getMonth(); // 0-based

  const firstDay = new Date(year, month, 1);
  const startDay = firstDay.getDay(); // 0 = Sunday

  const daysInMonth = new Date(year, month + 1, 0).getDate();

  calendar.innerHTML = "";

  days.forEach(d => {
    const dayElem = document.createElement("div");
    dayElem.className = "day-header";
    dayElem.innerText = d;
    calendar.appendChild(dayElem);
  });

  for (let i = 0; i < startDay; i++) {
    const blank = document.createElement("div");
    calendar.appendChild(blank);
  }

  for (let i = 1; i <= daysInMonth; i++) {
    const dateElem = document.createElement("div");
    dateElem.className = "date";
    const dateStr = `${year}-${String(month + 1).padStart(2, '0')}-${String(i).padStart(2, '0')}`;
    dateElem.textContent = i;
    dateElem.dataset.date = dateStr;

    dateElem.addEventListener("click", () => {
      hiddenDate.value = dateStr;
      document.querySelectorAll(".date").forEach(d => d.classList.remove("selected"));
      dateElem.classList.add("selected");
    });

    calendar.appendChild(dateElem);
  }
}

generateCalendar();

// Form submit
const form = document.getElementById("appointmentForm");

form.addEventListener("submit", function(e) {
  e.preventDefault();

  if (!hiddenDate.value) {
    alert("Please select a date from the calendar.");
    return;
  }

  const name = document.getElementById("name").value;
  const email = document.getElementById("email").value;
  const date = hiddenDate.value;
  const time = document.getElementById("time").value;
  const dept = department.value;
  const doc = doctor.value;

  const appointment = {
    id: Date.now().toString(),
    name,
    email,
    date,
    time,
    department: dept,
    doctor: doc
  };

  // Save to current user
  if (currentUser) {
    currentUser.appointments.push(appointment);
    const userIndex = users.findIndex(u => u.id === currentUser.id);
    if (userIndex !== -1) {
      users[userIndex] = currentUser;
      localStorage.setItem('users', JSON.stringify(users));
      sessionStorage.setItem('currentUser', JSON.stringify(currentUser));
    }
  }

  // Show confirmation
  document.getElementById("popupDetails").innerHTML = `
    <strong>${name}</strong><br>
    Email: ${email}<br>
    Date: ${date}<br>
    Time: ${time}<br>
    Department: ${dept}<br>
    Doctor: ${doc}
  `;

  document.getElementById("popup").style.display = "block";
  document.getElementById("overlay").style.display = "block";

  form.reset();
  hiddenDate.value = "";
  document.querySelectorAll(".date").forEach(d => d.classList.remove("selected"));
});

function closePopup() {
  document.getElementById("popup").style.display = "none";
  document.getElementById("overlay").style.display = "none";
}